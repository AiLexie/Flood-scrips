# DDoS-Scripts
DDoS Scripts for VPS Booters, Dedicated servers ect..

Compile with GCC (apt-get install gcc / yum install gcc)

